#' @docType package
#' @aliases gt-package
"_PACKAGE"
