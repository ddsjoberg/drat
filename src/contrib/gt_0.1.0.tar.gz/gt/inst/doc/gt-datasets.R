## ----options, message=FALSE, warning=FALSE, include=FALSE---------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>")

library(gt)
library(dplyr)
library(tidyr)

## ----countrypops_make_data_dictionary, echo=FALSE-----------------------------
countrypops_ddtab <-
  dplyr::tribble(
    ~Column,          ~Type,  ~Description,
    "country_name",   "chr", "Name of the country",
    "country_code_2", "chr", "The 2-letter ISO 3166-1 country code",
    "country_code_3", "chr", "The 3-letter ISO 3166-1 country code",
    "year",           "int", "The year for the population estimate",
    "population",     "int", "The population estimate, midway through the year",
  ) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----countrypops_ddtab, echo = FALSE------------------------------------------
countrypops_ddtab

## ----countrypops--------------------------------------------------------------
# Get vectors of 2-letter country codes for
# each region of Oceania
Australasia <- c("AU", "NZ")
Melanesia <- c("NC", "PG", "SB", "VU")
Micronesia <- c("FM", "GU", "KI", "MH", "MP", "NR", "PW")
Polynesia <- c("PF", "WS", "TO", "TV")

# Create a gt table based on a preprocessed `countrypops`
countrypops %>%
  dplyr::filter(country_code_2 %in% c(
    Australasia, Melanesia, Micronesia, Polynesia)
  ) %>%
  dplyr::filter(year %in% c(1995, 2005, 2015)) %>%
  dplyr::mutate(region = case_when(
    country_code_2 %in% Australasia ~ "Australasia",
    country_code_2 %in% Melanesia ~ "Melanesia",
    country_code_2 %in% Micronesia ~ "Micronesia",
    country_code_2 %in% Polynesia ~ "Polynesia",
  )) %>%
  tidyr::spread(key = year, value = population) %>%
  dplyr::arrange(region, desc(`2015`)) %>%
  dplyr::select(-starts_with("country_code")) %>%
  gt(
    rowname_col = "country_name",
    groupname_col = "region"
  ) %>%
  tab_header(title = "Populations of Oceania's Countries in 1995, 2005, and 2015") %>%
  tab_spanner(
    label = "Total Population",
    columns = vars(`1995`, `2005`, `2015`)
  ) %>%
  fmt_number(
    columns = vars(`1995`, `2005`, `2015`),
    decimals = 0,
    use_seps = TRUE
  )

## ----sza_make_data_dictionary, echo=FALSE-------------------------------------
sza_ddtab <-
  dplyr::tribble(
    ~Column,      ~Type,  ~Description,
    "latitude",   "dbl", "The latitude in decimal degrees for the observations",
    "month",      "fct", "The measurement month; all calculations where conducted for the first day of each month",
    "tst",        "chr", "The true solar time at the given latitude and date (first of month) for which the solar zenith angle is calculated",
    "sza",        "dbl", "The solar zenith angle in degrees, where NAs indicate that sunrise hadn't yet occurred by the tst value",
  ) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----sza_ddtab, echo = FALSE--------------------------------------------------
sza_ddtab

## ----sza----------------------------------------------------------------------
# Create a gt table based on a preprocessed `sza`
sza %>%
  dplyr::filter(latitude == 20) %>%
  dplyr::select(-latitude) %>%
  dplyr::filter(!is.na(sza)) %>%
  tidyr::spread(key = "tst", value = sza) %>%
  gt(rowname_col = "month") %>%
  fmt_missing(
    columns = TRUE,
    missing_text = ""
  ) %>%
  tab_stubhead(label = html("month<br>(20&deg;N)")) %>%
  tab_header(title = html("&#x2600; Solar Zenith Angles &#x2600;")) %>%
  tab_options(
    column_labels.font.size = "smaller",
    table.font.size = "smaller",
    data_row.padding = px(3)
  )

## ----gtcars_make_data_dictionary, echo=FALSE----------------------------------
gtcars_ddtab <-
  dplyr::tribble(
    ~Column,      ~Type,  ~Description,
    "mfr",       "chr", "The name of the car manufacturer",
    "model",     "chr", "The car's model name",
    "year",      "int", "The car's model year",
    "trim",      "chr", "A short description of the car model's trim",
    "bdy_style", "chr", "An identifier of the car's body style, which is either coupe, convertible,     sedan, or hatchback",
    "hp, hp_rpm", "int", "The car's horsepower and the associated RPM level",
    "trq, trq_rpm", "int", "The car's torque and the associated RPM level",
    "mpg_c, mpg_h", "int", "The miles per gallon fuel efficiency rating for city and highway driving",
    "drivetrain", "chr", "The car's drivetrain which, for this dataset is either rwd (Rear Wheel Drive)     or awd (All Wheel Drive)",
    "trsmn",     "chr", "The codified transmission type, where the number part is the number of gears; the car could have automatic transmission (a), manual transmission (m), an option to switch between both types (am), or, direct drive (dd)",
    "ctry_origin", "chr", "The country name for where the vehicle manufacturer is headquartered",
  ) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----gtcars_ddtab, echo = FALSE-----------------------------------------------
gtcars_ddtab

## ----gtcars-------------------------------------------------------------------
# Create a gt table based on a preprocessed `gtcars`
gtcars %>%
  dplyr::filter(ctry_origin == "Germany") %>%
  dplyr::group_by(mfr) %>%
  dplyr::top_n(2, msrp) %>%
  dplyr::ungroup() %>%
  dplyr::select(mfr, model, drivetrain, msrp) %>%
  gt() %>%
  tab_header(title = "Select German Automobiles") %>%
  cols_merge(
    columns = vars(mfr, model),
    hide_columns = vars(model)
  ) %>%
  text_transform(
    locations = cells_data(columns = vars(drivetrain)),
    fn = function(x) toupper(x)
  ) %>%
  fmt_currency(
    columns = vars(msrp),
    currency = "USD",
    decimals = 0
  ) %>%
  cols_label(
    mfr = "Car",
    drivetrain = "Drivetrain",
    msrp = "MSRP"
  ) %>%
  tab_footnote(
    footnote = "Prices in USD.",
    locations = cells_column_labels(columns = vars(msrp))
  ) %>%
  tab_footnote(
    footnote = "AWD = All Wheel Drive, RWD = Rear Wheel Drive.",
    locations = cells_column_labels(columns = vars(drivetrain))
  ) %>%
  opt_footnote_marks(marks = "letters")

## ----sp500_make_data_dictionary, echo=FALSE-----------------------------------
sp500_ddtab <-
  dplyr::tribble(
    ~Column,     ~Type,  ~Description,
    "date",      "date", "The date expressed as `Date` values",
    "open, high, low, close", "dbl", "The day's opening, high, low, and closing prices in USD; the close price is adjusted for splits",
    "volume",    "dbl", "The number of trades for the given `date`",
    "adj_close", "dbl", "The close price adjusted for both dividends and splits",
  ) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----sp500_ddtab, echo = FALSE------------------------------------------------
sp500_ddtab

## ----sp500--------------------------------------------------------------------
# Define the start and end dates for the data range
start_date <- "2010-06-02"
end_date <- "2010-06-15"

# The HTML decimal references for the black
# up- and down-pointing triangles are: #9650 and #9660;
# use an in-line style to apply color
up_arrow <- "<span style=\"color:green\">&#9650;</span>"
down_arrow <- "<span style=\"color:red\">&#9660;</span>"

# Create a gt table based on a preprocessed `sp500`
sp500 %>%
  dplyr::filter(date >= start_date & date <= end_date) %>%
  dplyr::select(-adj_close) %>%
  gt() %>%
  tab_header(
    title = "S&P 500",
    subtitle = glue::glue("{start_date} to {end_date}")
  ) %>%
  fmt_date(
    columns = vars(date),
    date_style = 7
  ) %>%
  fmt_currency(
    columns = vars(open, high, low, close),
    currency = "USD"
  ) %>%
  fmt_number(
    columns = vars(volume),
    scale_by = 1 / 1E9,
    pattern = "{x}B"
  ) %>%
  text_transform(
    locations = cells_data(
      columns = "close",
      rows = close > open),
    fn = function(x) paste(x, up_arrow)
  ) %>%
  text_transform(
    locations = cells_data(
      columns = "close",
      rows = close < open),
    fn = function(x) paste(x, down_arrow)
  ) %>%
  cols_label(
    date = "Date", open = "Open", high = "High",
    low = "Low", close = "Close", volume = "Volume"
  )

## ----pizzaplace_make_data_dictionary, echo=FALSE------------------------------
pizzaplace_ddtab <-
  dplyr::tribble(
    ~Column,      ~Type,  ~Description,
    "id", "chr", "The ID for the order, which consists of one or more pizzas at a given `date` and `time`",
    "date", "chr", "A character representation of the order `date`, expressed in the ISO 8601 date format (YYYY-MM-DD)",
    "time", "chr", "A character representation of the order time, expressed as a 24-hour time the ISO 8601 extended time format (hh:mm:ss)",
    "name", "chr", "The short name for the pizza",
    "size", "chr", "The size of the pizza, which can either be S, M, L, XL (rare!), or XXL (even rarer!); most pizzas are available in the S, M, and L sizes but exceptions apply",
    "type", "chr", "The category or type of pizza, which can either be `classic`, `chicken`, `supreme`, or `veggie`",
    "price", "dbl", "The price of the pizza and the amount that it sold for (in USD)",
) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----pizzaplace_ddtab, echo = FALSE-------------------------------------------
pizzaplace_ddtab

## ----pizzaplace---------------------------------------------------------------
# Create a gt table based on a preprocessed `pizzaplace`
pizzaplace %>%
  dplyr::group_by(type, size) %>%
  dplyr::summarize(
    sold = n(),
    income = sum(price)
  ) %>%
  gt(rowname_col = "size") %>%
  tab_header(title = "Pizzas Sold in 2015") %>%
  fmt_number(
    columns = vars(sold),
    decimals = 0,
    use_seps = TRUE
  ) %>%
  fmt_currency(
    columns = vars(income),
    currency = "USD"
  ) %>%
  summary_rows(
    groups = TRUE,
    columns = vars(sold),
    fns = list(TOTAL = "sum"),
    formatter = fmt_number,
    decimals = 0,
    use_seps = TRUE
  ) %>%
  summary_rows(
    groups = TRUE,
    columns = "income",
    fns = list(TOTAL = "sum"),
    formatter = fmt_currency,
    currency = "USD"
  ) %>%
  tab_options(
    summary_row.background.color = "#ACEACE",
    row_group.background.color = "#FFEFDB"
  )

## ----exibble_make_data_dictionary, echo=FALSE---------------------------------
exibble_ddtab <-
  dplyr::tribble(
    ~Column,      ~Type,  ~Description,
    "num",        "dbl", "A numeric column ordered with increasingly larger values",
    "char",       "chr", "A character column composed of names of fruits from a to h",
    "fctr",       "fct", "A factor column with numbers from 1 to 8, written out",
    "date, time, datetime", "chr", "Character columns with dates, times, and datetimes",
    "currency",   "dbl", "A numeric column that is useful for testing currency-based formatting",
    "row",        "chr", "A character column in the format `row_X` which can be useful for testing with row label in a table stub",
    "group",      "chr", "A character column with four `grp_a` values and four `grp_b` values which can be useful for testing tables that contain row groups",
  ) %>%
  gt() %>%
  tab_style(
    style = cell_text(font = "Courier"),
    locations = list(
      cells_data(columns = "Column"),
      cells_data(columns = "Type"))
  ) %>%
  tab_options(
    table.width = pct(80),
    table.font.size = "smaller",
    column_labels.font.size = "small"
  )

## ----exibble_ddtab, echo = FALSE----------------------------------------------
exibble_ddtab

## ----exibble------------------------------------------------------------------
# Create a gt table based on `exibble`
exibble %>%
  gt(
    rowname_col = "row",
    groupname_col = "group"
  ) %>%
  fmt_number(
    columns = vars(num),
    decimals = 2) %>%
  fmt_date(
    columns = vars(date),
    date_style = 6
  ) %>%
  fmt_time(
    columns = vars(time),
    time_style = 4
  ) %>%
  fmt_datetime(
    columns = vars(datetime),
    date_style = 6,
    time_style = 4
  ) %>%
  fmt_currency(
    columns = vars(currency),
    currency = "EUR"
  ) %>%
  tab_options(
    column_labels.font.size = "small",
    table.font.size = "small",
    row_group.font.size = "small",
    data_row.padding = px(3)
  )

